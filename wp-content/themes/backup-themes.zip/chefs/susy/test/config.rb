# Compass CSS framework config file

project_type = :stand_alone
http_path = "/"
sass_dir = "scss"
css_dir = "css"
line_comments = false
preferred_syntax = :scss
output_style = :nested
relative_assets = true
